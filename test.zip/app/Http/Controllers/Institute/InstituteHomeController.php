<?php

namespace App\Http\Controllers\Institute;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;

class InstituteHomeController extends Controller
{
    public function index() {
        $userCount = User::where('ins_id', auth()->user()->id)->count();
        return view('institute.index', compact('userCount'));
    }

    public function userList(){
        $users = User::where('ins_id', auth()->user()->id)->get();
        return view('institute.user-list', compact('users'));
    }
}
